<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Book Store</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<style>

</style>

<body>
    <div class="container mt-5">
        <div class="row">
            <div class="col-sm-6">

                <form action="do_home.php" method="POST" enctype="multipart/form-data">
                    <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Book Name</label>
                        <input type="text" class="form-control" name="book_name">

                    </div>
                    <div class="mb-3">
                        <label for="exampleInputPassword1" class="form-label">Title</label>
                        <input type="text" class="form-control" name="title">
                    </div>
                    <div class="mb-3">
                        <label for="exampleInputPassword1" class="form-label">Author Name</label>
                        <input type="text" class="form-control" name="author_name">
                    </div>
                    <div class="mb-3">
                        <label for="exampleFormControlFile1">Title Page</label>
                        <input type="file" class="form-control-file" name="image">
                    </div>
                    <button type="submit" class="btn btn-primary" name="submit">Submit</button>
                </form>
            </div>
        </div>
    </div>

</body>

</html>