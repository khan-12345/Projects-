<?php
require_once('database.php');

$db = new Database();

$fn = $_POST['fname'];
$ag = $_POST['age'];
$gen = $_POST['gender'];
$ema = $_POST['email'];
$phoNum = $_POST['phoneNumber'];
$bir = $_POST['birthday'];
$deg = $_POST['degree_program'];

$rest = $db->add_students($fn, $ag, $gen, $ema, $phoNum, $bir, $deg);

include('add_students.php');

?>