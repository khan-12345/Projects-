<?php
    require_once('Database.php');
    $db = new Database();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/add_students.css">
    <title>Document</title>
</head>
<body>
    <?php
    include('home.php');
    ?>
    <section class="container">
        <header>Student Record</header>
    <?php
        $std = $db->fetchSingleStudentRecord($_GET['id']);
        foreach($std as $row){
    ?>
        <form action="do_update_students.php" class="form" method="post">
            <input type="hidden" name="student_id" value="<?php echo $_GET['id']?>">
            <div class="column">
                <div class="input-box">
                    <label>Full Name</label>
                    <input type="text" placeholder="Enter Full Name" name="fname" value="<?php echo $row[1]; ?>" required />
                </div>
            </div>

            <div class="column">
                <div class="input-box">
                    <label>Age</label>
                    <input type="number" placeholder="Enter Age" name="age" value="<?php echo $row[2]; ?>" required />
                </div>
                <div class="input-box">
                    <label>Gender</label>
                    <div class="select-box">
                        <select name="gender" value="<?php echo $row[3]; ?>">
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>
                </div>
            </div>

            <div class="column">
                <div class="input-box">
                    <label>Email</label>
                    <input type="email" placeholder="Enter Email" name="email" value="<?php echo $row[4]; ?>" required />
                </div>
                <div class="input-box">
                    <label>Phone Number</label>
                    <input type="text" placeholder="Enter Phone Number" name="phoneNumber" value="<?php echo $row[5]; ?>" required />
                </div>
            </div>

            <div class="column">
                <div class="input-box">
                    <label>Birthday</label>
                    <input type="date" placeholder="Enter your birthday" name="birthday" value="<?php echo $row[6]; ?>" required />
                </div>
                <div class="input-box">
                    <label>Degree Program</label>
                    <div class="select-box">
                        <select name="degree_program" value="<?php echo $row[7]; ?>">
                            <!-- <option hidden>Degree Program</option> -->
                            <option value="BSSE">BSSE</option>
                            <option value="BSCS">BSCS</option>
                            <option value="BSIT">BSIT</option>
                            <option value="BSAI">BSAI</option>
                        </select>
                    </div>
                </div>
            </div>
            <button type="submit">Update</button>
        </form>
        <?php }?>
    </section>
</body>
</html>