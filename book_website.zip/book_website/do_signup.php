<?php
require_once('database.php');

$db = new Database();

$ema = $_POST['email'];
$pass = md5($_POST['password']);

$res = $db->signup($ema, $pass);

if($res === true){
    header('location:login.php?rid=3');
}
else{
    header('location:signup.php?rid=4');
}

?>