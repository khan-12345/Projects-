<?php
class Database{
    private $db;

    function __construct(){
        try{
            $this->db = new PDO("mysql:host=localhost;dbname=student_management_system",
                "root",
                "");
            $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);;
            //print('db connected');
        }
        catch(PDOException $e){
            die($e->getMessage());
        }
    }
    function signup($email, $password){
        try{
            $sql = "INSERT INTO `login` (`id`, `email`, `password`) VALUES (NULL, ?, ?);";
            $st = $this->db->prepare($sql);
            $st->execute(array($email, $password));
            return true;
        }
        catch(PDOException $e){
            return false;
        }        
    }

    function signIn($email, $password){
        $sql = "SELECT id FROM `login` WHERE `email` = ? AND `password` = ?;";
        $st = $this->db->prepare($sql);
        $st->execute(array($email, $password));

        if($st->rowCount() == 1 ){
            return true;
        }
        else{
            false;
        }
    }

    function add_students($fname, $age, $gender, $email, $phoneNumber, $birthday, $degree_program){
        try{
            $sql_student = "INSERT INTO `student` (`student_id`, `student_name`, `student_age`, `student_gender`, `student_email`, `student_phone_number`, `student_birthday`, `student_degree_program`) VALUES (NULL, ?, ?, ?, ?, ?, ?, ?);";
            $std = $this->db->prepare($sql_student);
            $std->execute(array($fname, $age, $gender, $email, $phoneNumber, $birthday, $degree_program));
            return true;
        }
        catch(PDOException $e){
            return false;
        }        
    }

    function fetchSingleStudentRecord($studentId){
        $sql_student = "SELECT * FROM student WHERE `student_id`=$studentId;";
        $std = $this->db->prepare($sql_student);
        $std->execute(array());
        return $std;
    }

    function update_students($fname, $age, $gender, $email, $phoneNumber, $birthday, $degree_program,$studentId){
        try{
            $sql_student = "UPDATE `student` SET  `student_name`=?, `student_age`=?, `student_gender`=?, `student_email`=?, `student_phone_number`=?, `student_birthday`=?, `student_degree_program`= ? WHERE `student_id`=$studentId;";
            $std = $this->db->prepare($sql_student);
            $std->execute(array($fname, $age, $gender, $email, $phoneNumber, $birthday, $degree_program));
            return true;
        }
        catch(PDOException $e){
            return false;
        }        
    }

    function fetchAllStudents(){
        $sql_student = "SELECT * FROM student";
        $std = $this->db->prepare($sql_student);
        $std->execute(array());
        return $std;
    }

    function deleteStudent($id){
        $sql = "DELETE FROM student WHERE student_id = ?";
        $std = $this->db->prepare($sql);
        $std->execute(array($id));
    }

    function add_teachers($fname, $age, $gender, $email, $phoneNumber, $birthday, $designation){
        try{
            $sql_teacher = "INSERT INTO `teacher` (`teacher_id`, `teacher_name`, `teacher_age`, `teacher_gender`, `teacher_email`, `teacher_phone_number`, `teachert_birthday`, `teacher_designation`) VALUES (NULL, ?, ?, ?, ?, ?, ?, ?);";
            $stv = $this->db->prepare($sql_teacher);
            $stv->execute(array($fname, $age, $gender, $email, $phoneNumber, $birthday, $designation));
            return true;
            
        }
        catch(PDOException $e){
            return false;
        }        
    }
}