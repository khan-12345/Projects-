<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <link rel="stylesheet" href="css/login.css">
    <title>TMS</title>
</head>

<body>
    <?php
    if (isset($_GET['rid'])) {
        print('<div class="alert alert-danger alert-dismissible col-lg-6">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
            <strong>Invalid username or password</strong></div>');
    }
    ?>

    <section class="Form my-4 my-5">
        <div class="container ">
            <div class="row no-gutters">
                <div class="col-lg-5">
                    <img src="images/Login.jpg" class="img-fluid" alt="This is an image">
                </div>
                <div class="col-lg-7 px-5 pt-5">
                    <h2 class="font-weight-bold py-3">SIAC</h2>
                    <h4>Sign in to your account</h4>
                    <form action="do_login.php" method="post">
                        <div class="form-row">
                            <div class="col-lg-7">
                                <input type="email" class="form-control my-3 p-4" placeholder="Email" name="email" id="email">
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="col-lg-7">
                                <input type="password" class="form-control my-3 p-4" placeholder="Password" name="password" id="password">
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="col-lg-7">
                                <a href="./home.php"><button type="submit" class="btn1 mt-3 mb-4">Login</button></a>

                            </div>
                        </div>
                        <div>
                            <p>Don't have an account? <a href="./signup.php">Register here</a></p>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </section>



    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body>

</html>