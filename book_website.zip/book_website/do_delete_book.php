<?php
    $id = $_GET['id'];

    require_once('database.php');
    
    $db = new Database();
    
    $db->deleteStudent($id);

    include('view_students.php');
?>