<?php

require_once('database.php');

$db = new Database();

$id = $_POST['student_id'];
$fn = $_POST['fname'];
$ag = $_POST['age'];
$gen = $_POST['gender'];
$ema = $_POST['email'];
$phoNum = $_POST['phoneNumber'];
$bir = $_POST['birthday'];
$deg = $_POST['degree_program'];

$rest = $db->update_students($fn, $ag, $gen, $ema, $phoNum, $bir, $deg, $id);

include('view_students.php');


?>